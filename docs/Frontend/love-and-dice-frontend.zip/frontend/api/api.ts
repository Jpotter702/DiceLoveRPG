// Stub for api.ts
