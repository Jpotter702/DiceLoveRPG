// Stub for traitUtils.ts
