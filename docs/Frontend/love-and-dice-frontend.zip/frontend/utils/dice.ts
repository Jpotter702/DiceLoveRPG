// Stub for dice.ts
