// Stub for NPCProfile.tsx
