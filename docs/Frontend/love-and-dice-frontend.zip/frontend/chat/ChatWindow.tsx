// Stub for ChatWindow.tsx
