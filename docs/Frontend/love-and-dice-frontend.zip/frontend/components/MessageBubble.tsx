// Stub for MessageBubble.tsx
