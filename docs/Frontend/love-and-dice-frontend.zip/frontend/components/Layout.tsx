// Stub for Layout.tsx
