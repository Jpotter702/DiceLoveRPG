// Stub for CharacterContext.tsx
