// Stub for ChatContext.tsx
