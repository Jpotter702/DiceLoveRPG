// Stub for index.tsx
