# Love & Dice RPG

This is the backend and frontend scaffold for the Love & Dice AI roleplaying game.