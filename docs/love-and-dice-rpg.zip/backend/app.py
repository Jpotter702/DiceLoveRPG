# Entry point for the backend application
