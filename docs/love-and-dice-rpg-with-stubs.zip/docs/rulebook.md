# Love & Dice RPG - Rulebook

Core mechanics, Geist Rolls, Affection Points, and system overview will go here.
